Arduino-MMA7361-library
=======================

Arduino library for the MMA7361 3-axis MEMS accelerometer

